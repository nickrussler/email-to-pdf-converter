var searchData=
[
  ['headerfooter_77',['HeaderFooter',['../structwkhtmltopdf_1_1settings_1_1HeaderFooter.html',1,'wkhtmltopdf::settings']]]
];
