var searchData=
[
  ['margin_79',['Margin',['../structwkhtmltopdf_1_1settings_1_1Margin.html',1,'wkhtmltopdf::settings']]]
];
