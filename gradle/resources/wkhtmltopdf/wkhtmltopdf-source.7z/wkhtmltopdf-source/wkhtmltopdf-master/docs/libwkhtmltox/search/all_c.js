var searchData=
[
  ['setting_57',['Setting',['../pagesettings.html',1,'']]],
  ['screenheight_58',['screenHeight',['../structwkhtmltopdf_1_1settings_1_1ImageGlobal.html#a82868dfbcdaec2410c800c9228de6123',1,'wkhtmltopdf::settings::ImageGlobal']]],
  ['screenwidth_59',['screenWidth',['../structwkhtmltopdf_1_1settings_1_1ImageGlobal.html#abc5f83ea06d4524a76cc1c29f64a4c0e',1,'wkhtmltopdf::settings::ImageGlobal']]],
  ['size_60',['Size',['../structwkhtmltopdf_1_1settings_1_1Size.html',1,'wkhtmltopdf::settings::Size'],['../structwkhtmltopdf_1_1settings_1_1PdfGlobal.html#aeea9003f7853aade329e514b8ad8ab0b',1,'wkhtmltopdf::settings::PdfGlobal::size()']]],
  ['spacing_61',['spacing',['../structwkhtmltopdf_1_1settings_1_1HeaderFooter.html#a19033dd004f2de54fdd0f7bb40a81072',1,'wkhtmltopdf::settings::HeaderFooter']]]
];
