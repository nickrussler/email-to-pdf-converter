---
name: "\U0001F680 Feature request"
about: Ideas for new features and improvements.

---

**Description**
<!-- A clear and concise description of the new feature. -->

**Example**  
<!-- A simple example of the new feature in action. -->
